<html>
<head>
</head>
<body>

<h1>manager</h1><img src="ajay1.jpg" height="300px";width="150px"/>
<h1>manager</h1><img src="ajay1.jpg" height="300px";width="150px"/>
<h1>supplier</h1><img src="karthik.jpg" height="300px";width="150px"/>
<h1>supplier</h1><img src ="ajit.jpg" height="200px";width="350px"/>
<h1>baker</h1><img src="bavana.jpg" height="300px";width="150px"/>
</body>

</html>