<html>
<head>
	<title>About us</title>

<body>

	<div id = "heading">
		<h1>AJ AND AK BAKERY</h1>
	</div>

	<div class="container-fluid">
		<div class="row" >
		
			<div id=heading>
				<h2>Contact us</h2>
			</div>
			<p>contact us at ajaykumarc003@gmail.com</p>
			<p>7899457068</p>
			<p> to give ur valuable suggestions please visit feedback 
			<p><h1>Note</h1></p>
			
         <p>the  things which are deleted by  the customer will be automatically present in the product list and the things which are not available will be automatically deleted by the admin</p>
		 <p>please refer cupons and apply</p>
		 <p>new user please register and then login and enjoy</p>
		 <p>dont forgot to give ur valuable feedback</p>

			<div class="hr"></div>
		</div>

	</div>

	

</body>
</html>
