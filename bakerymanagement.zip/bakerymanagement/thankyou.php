<?php

   include('config.php');
?>
<html>
   
   <head>
    
  <body style="background-image:url('thank.jpg')">
      <title>Thanks</title>
	  <marquee> <h2>please give feedback and dont forgot to logout<h2></marquee>
   </head>
   
      
     <header style="position:absolute;top:40;right:30"> <a href="logout.php"><h2>logout</h2</a></header>
  <header style="position:absolute;top:50;left:30"> <a href="addfeedback.php"><h2>feedback</h2></a></header>
  </body>
   
</html>