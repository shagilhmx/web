<html>
<head>
	<title>About us</title>

<body>

	<div id = "heading">
		<h1>AJ AND AK BAKERY</h1>
	</div>

	<div class="container-fluid">
		<div class="row" >
		
			<div id=heading>
				<h2>Information</h2>
			</div>
			<p>Come And Eat Bakery , one of the toppest bakery of Bangalore.where we have all types of pasteries,cakes,veg cakes etc which are so tasty.now we have been developed a webpage so that you can get a home delivary  </p>
	        <p> we are using a fresh milk to prepare bread and bun and our we are using all ISI marked items only,You can come and check our accomodation and you can give the feed back according to that</p>
			<p>now we are developing online website to satisfy the customer who are very far that cannot come to our bakery you can just login to our web portal and you can get the items which ever you want</p>
			<p> after ordering even though it is to far we you get your order with in 3 hours</p>
			<div id=heading>
				<h2>Mission</h2>
			</div>
			<p>To keep customers satisfied by serving them quality and freshly baked goods at reasonable prices.</p>
									
			<div class="hr"></div>
		</div>
		<div class="row">
			<img src="image/meh.jpg" id="imgright">
			<div id=heading>
				<h2>Vision</h2>
			</div>
         <p>Katerina envisions to maintain a safe, healthy and vibrant workplace for its employees in order to serve our customers best.</p>

			<div class="hr"></div>
		</div>

	</div>

	

</body>
</html>
